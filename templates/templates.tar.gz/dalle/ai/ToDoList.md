# ToDoList

| Task                            | Step                                                                                          | Done  |
| ------------------------------- | --------------------------------------------------------------------------------------------- | :---: |
| 1. Modify Names Struct          | 1.1 Remove unsorted list fields (List, Custom, Prefund, Regular, Baddress)                    |   -   |
|                                 | 1.2 Add a new field sortedCache                                                               |   -   |
|                                 | 1.3 Source names from the Map as the sole data repository                                     |   -   |
| 2. Update GetNamesPage          | 2.1 Construct a cache key from list type, sort key, and sort direction                        |   -   |
|                                 | 2.2 Check sortedCache for an existing sorted list                                             |   -   |
|                                 | 2.3 If absent, generate the sorted list from the map and store it in the cache                |   -   |
|                                 | 2.4 Apply filtering on the cached sorted list                                                 |   -   |
|                                 | 2.5 Return the requested page from the filtered results                                       |   -   |
| 3. Update LoadNames/ReloadNames | 3.1 Remove legacy list assignments                                                            |   -   |
|                                 | 3.2 Clear the sortedCache upon loading or reloading names                                     |   -   |
| 4. Testing                      | 4.1 Write unit tests for GetNamesPage page retrieval with various sort criteria               |   -   |
|                                 | 4.2 Write tests to verify caching reduces redundant sorting calls                             |   -   |
|                                 | 4.3 Write integration tests to ensure LoadNames/ReLoadNames correctly clear and rebuild cache |   -   |
|                                 | 4.4 Perform performance tests simulating rapid paging                                         |   -   |
