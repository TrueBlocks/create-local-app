export const Khedra = () => {
  return <div>Khedra</div>;
};
