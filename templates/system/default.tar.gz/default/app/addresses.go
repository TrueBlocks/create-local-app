package app

import (
	"fmt"
	"strings"
	"sync"

	"{{CHIFRA}}/pkg/base"
	sdk "github.com/{{ORG_NAME}}/{{ORG_LOWER}}-sdk/v5"
)

var ensLock sync.Mutex

func (a *App) ConvertToAddress(addr string) (base.Address, bool) {
	if !strings.HasSuffix(addr, ".eth") {
		ret := base.HexToAddress(addr)
		return ret, ret != base.ZeroAddr
	}

	ensLock.Lock()
	ensAddr, exists := a.ensMap[addr]
	ensLock.Unlock()

	if exists {
		return ensAddr, true
	}

	// Try to get an ENS or return the same input
	opts := sdk.NamesOptions{
		Terms: []string{addr},
	}
	if names, _, err := opts.Names(); err != nil {
		// msgs.Send(a.ctx, msgs.Error, msgs.NewErrorMsg(err))
		return base.ZeroAddr, false
	} else {
		if len(names) > 0 {
			ensLock.Lock()
			defer ensLock.Unlock()
			a.ensMap[addr] = names[0].Address
			return names[0].Address, true
		} else {
			ret := base.HexToAddress(addr)
			return ret, ret != base.ZeroAddr
		}
	}
}

func (a *App) SetActiveAddress(addr base.Address) error {
	if active := a.GetActiveProject(); active != nil {
		return active.SetActiveAddress(addr)
	}
	return fmt.Errorf("no active project")
}

func (a *App) AddAddressToProject(addr base.Address) error {
	if active := a.GetActiveProject(); active != nil {
		return active.AddAddress(addr)
	}
	return fmt.Errorf("no active project")
}

func (a *App) RemoveAddressFromProject(addr base.Address) error {
	if active := a.GetActiveProject(); active != nil {
		return active.RemoveAddress(addr)
	}
	return fmt.Errorf("no active project")
}

func (a *App) SetActiveContract(contract string) error {
	if active := a.GetActiveProject(); active != nil {
		return active.SetActiveContract(contract)
	}
	return fmt.Errorf("no active project")
}
