package app

import (
	"fmt"
	"strings"
	"sync"

	"{{CHIFRA}}/pkg/base"
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/msgs"
	sdk "github.com/{{ORG_NAME}}/{{ORG_LOWER}}-sdk/v5"
)

var ensLock sync.Mutex

func (a *App) ConvertToAddress(addr string) (base.Address, bool) {
	if !strings.HasSuffix(addr, ".eth") {
		ret := base.HexToAddress(addr)
		return ret, ret != base.ZeroAddr
	}

	ensLock.Lock()
	ensAddr, exists := a.ensMap[addr]
	ensLock.Unlock()

	if exists {
		return ensAddr, true
	}

	// Try to get an ENS or return the same input
	opts := sdk.NamesOptions{
		Terms: []string{addr},
	}
	if names, _, err := opts.Names(); err != nil {
		return base.ZeroAddr, false
	} else {
		if len(names) > 0 {
			ensLock.Lock()
			defer ensLock.Unlock()
			a.ensMap[addr] = names[0].Address
			return names[0].Address, true
		} else {
			ret := base.HexToAddress(addr)
			return ret, ret != base.ZeroAddr
		}
	}
}

func (a *App) SetActiveAddress(addrStr string) error {
	addr := base.HexToAddress(addrStr)
	if active := a.GetActiveProject(); active != nil {
		err := active.SetActiveAddress(addr)
		if err == nil {
			msgs.EmitManager("active_address_changed")
		}
		return err
	}
	return fmt.Errorf("no active project")
}

func (a *App) AddAddressToProject(addrStr string) error {
	addr := base.HexToAddress(addrStr)
	if active := a.GetActiveProject(); active != nil {
		return active.AddAddress(addr)
	}
	return fmt.Errorf("no active project")
}

func (a *App) RemoveAddressFromProject(addrStr string) error {
	addr := base.HexToAddress(addrStr)
	if active := a.GetActiveProject(); active != nil {
		return active.RemoveAddress(addr)
	}
	return fmt.Errorf("no active project")
}

func (a *App) SetActiveContract(contract string) error {
	if active := a.GetActiveProject(); active != nil {
		return active.SetActiveContract(contract)
	}
	return fmt.Errorf("no active project")
}
