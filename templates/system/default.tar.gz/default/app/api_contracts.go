// Copyright 2016, 2026 The Authors. All rights reserved.
// Use of this source code is governed by a license that can
// be found in the LICENSE file.
/*
 * Parts of this file were auto generated. Edit only those parts of
 * the code inside of 'EXISTING_CODE' tags.
 */

package app

import (
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/types"
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/types/contracts"

	//
	sdk "github.com/{{ORG_NAME}}/{{ORG_LOWER}}-sdk/v5"
	// EXISTING_CODE
	// EXISTING_CODE
)

func (a *App) GetContractsPage(
	payload *types.Payload,
	first, pageSize int,
	sort sdk.SortSpec,
	filter string,
) (*contracts.ContractsPage, error) {
	collection := contracts.GetContractsCollection(payload)
	return getCollectionPage[*contracts.ContractsPage](collection, payload, first, pageSize, sort, filter)
}

func (a *App) GetContractsSummary(payload *types.Payload) types.Summary {
	collection := contracts.GetContractsCollection(payload)
	return collection.GetSummary()
}

func (a *App) ReloadContracts(payload *types.Payload) error {
	collection := contracts.GetContractsCollection(payload)
	collection.Reset(payload.DataFacet)
	collection.LoadData(payload.DataFacet)
	return nil
}

// GetContractsConfig returns the view configuration for contracts
func (a *App) GetContractsConfig(payload types.Payload) (*types.ViewConfig, error) {
	collection := contracts.GetContractsCollection(&payload)
	return collection.GetConfig()
}

// EXISTING_CODE
// EXISTING_CODE
