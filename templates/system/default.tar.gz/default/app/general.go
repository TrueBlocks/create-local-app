package app

import (
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/store"
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/types"
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/types/names"

	"{{CHIFRA}}/pkg/base"
)

// NameFromAddress resolves an Ethereum address to a named entity if one exists
func (a *App) NameFromAddress(address string) (*names.Name, bool) {
	collection := names.GetNamesCollection(&types.Payload{})
	return collection.NameFromAddress(base.HexToAddress(address))
}

// CancelFetch cancels an active data fetch operation for a specific data facet
func (a *App) CancelFetch(dataFacet types.DataFacet) {
	for _, collection := range a.collections {
		supportedFacets := collection.GetSupportedFacets()
		for _, facet := range supportedFacets {
			if facet == dataFacet {
				// TODO: BOGUS - this does not reset export which requires chain and address to find the collection
				storeName := collection.GetStoreName(facet, "", "")
				store.CancelFetch(storeName)
				return
			}
		}
	}
}

// CancelAllFetches cancels all active fetch operations and returns the count of cancelled operations
func (a *App) CancelAllFetches() int {
	return store.CancelAllFetches()
}

// ResetStore resets the data store for all collections matching the given store name
func (a *App) ResetStore(storeName string) {
	for _, collection := range a.collections {
		for _, facet := range collection.GetSupportedFacets() {
			// TODO: BOGUS - this does not reset export which requires chain and address to find the collection
			if collection.GetStoreName(facet, "", "") == storeName {
				collection.Reset(facet)
			}
		}
	}
}
