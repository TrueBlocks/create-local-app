package app

import (
	"{{CHIFRA}}/pkg/base"
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/store"
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/types"
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/types/names"
)

// NameFromAddress resolves an Ethereum address to a named entity if one exists
func (a *App) NameFromAddress(address string) (*names.Name, bool) {
	collection := names.GetNamesCollection(&types.Payload{})
	return collection.NameFromAddress(base.HexToAddress(address))
}

// CancelFetch cancels an active data fetch operation for a specific data facet
func (a *App) CancelFetch(dataFacet types.DataFacet) {
	storeName := ""

	for _, collection := range a.collections {
		for _, facet := range collection.GetSupportedFacets() {
			if facet == dataFacet {
				storeName = collection.GetStoreName(facet)
				break
			}
		}
		if storeName != "" {
			break
		}
	}

	if storeName != "" {
		store.CancelFetch(storeName)
	}
}

// CancelAllFetches cancels all active fetch operations and returns the count of cancelled operations
func (a *App) CancelAllFetches() int {
	return store.CancelAllFetches()
}

// ResetStore resets the data store for all collections matching the given store name
func (a *App) ResetStore(storeName string) {
	for _, collection := range a.collections {
		for _, facet := range collection.GetSupportedFacets() {
			if collection.GetStoreName(facet) == storeName {
				collection.Reset(facet)
			}
		}
	}
}
