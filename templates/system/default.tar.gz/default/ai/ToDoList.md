# Project-Centric Architecture Implementation ToDoList

## Tasks

| Task | Step | Done |
|------|------|:---:|
| Task | Step | Done |
|------|------|:---:|
| **1. Enhance Backend Project Context APIs** | | |
| | 1. Add `GetProjectViewState(viewName)` method in `app/app.go` | ✅ |
| | 2. Add `SetProjectViewState(viewName, state)` method in `app/app.go` | ✅ |
| | 3. Add `RestoreProjectContext(projectID)` method in `app/app.go` | ✅ |
| | 4. Use existing `SaveProject()` method for capturing view states | ✅ |
| | 5. Update Wails bindings with `wails generate module` | ✅ |
| | **Checkpoint**: Backend APIs ready for frontend integration | ✅ |
| **2. Modify ViewContext for Selective Persistence** | | |
| | 1. Read current `frontend/src/contexts/ViewContext.tsx` | ✅ |
| | 2. Import new backend APIs from `@app` | ✅ |
| | 3. Modify `updateSorting` to persist to backend FilterStates | ✅ |
| | 4. Modify `updateFiltering` to persist to backend FilterStates | ✅ |
| | 5. Keep `updatePagination` memory-only (no backend persistence) | ✅ |
| | 6. Add error handling for backend state persistence | ✅ |
| | **Checkpoint**: ViewContext persists analytical state only | ✅ |
| **3. Implement Project Context Restoration** | | |
| | 1. Read current project switching logic in frontend | ✅ |
| | 2. Add `restoreAnalyticalStateFromProject()` function | ✅ |
| | 3. Modify project switch handler to restore sorting/filtering | ✅ |
| | 4. Ensure pagination resets to page 1 on project switch | ✅ |
| | 5. Add navigation to project's `LastView` on project open | ✅ |
| | **Checkpoint**: Project switching restores analytical context | ✅ |
| **4. Update useActiveProject Hook Architecture** | | |
| | 1. Read current `useActiveProject` hook implementation | ✅ |
| | 2. Change from global appPreferencesStore to project-centric data | ✅ |
| | 3. Update `activeAddress`, `activeChain`, `activeContract` sources | ✅ |
| | 4. Modify setters to update project context, not global state | ✅ |
| | 5. Add error handling for project context updates | ✅ |
| | **Checkpoint**: Hook reads from active project, not global prefs | ✅ |
| **5. Enhance File Operations for Full Context Restoration** | | |
| | 1. Read current file operation handlers in `app/app.go` | ✅ |
| | 2. Modify `FileOpen` to trigger analytical state restoration | ✅ |
| | 3. Add view state restoration to project opening flow | ✅ |
| | 4. Add navigation to project's `LastView` on open | ✅ |
| | 5. Ensure pagination starts at page 1 for opened projects | ✅ |
| | **Checkpoint**: File operations restore complete project context | ✅ |
| **6. Clean Up App Preferences Store** | | |
| | 1. Read current `appPreferencesStore` implementation | ✅ |
| | 2. Remove project-specific data caching from global store | ✅ |
| | 3. Keep only global settings (theme, language, bounds, etc.) | ✅ |
| | 4. Update components to use project data from active project | ✅ |
| | 5. Test global preferences functionality still works | ✅ |
| | **Checkpoint**: App preferences scoped to global UI settings only | ✅ |
| **7. Add Performance Optimizations** | | |
| | 1. Implement debounced saving for analytical state changes | ✅ |
| | 2. Add state caching to avoid excessive backend calls | ✅ |
| | 3. Add background sync for critical state changes | ✅ |
| | 4. Add lazy loading for view states on-demand | ✅ |
| | 5. Add state validation and recovery mechanisms | ✅ |
| | **Checkpoint**: Performance optimized for state persistence | ✅ |
| **8. Enhance Project Selection UX** | | |
| | 1. Read current project selection modal implementation | ✅ |
| | 2. Add context preview (last view, active address, chain) | ✅ |
| | 3. Add visual indicators for project state (dirty, last opened) | ✅ |
| | 4. Add UI feedback for project context loading states | ✅ |
| | 5. Add project statistics and metadata display | ✅ |
| | **Checkpoint**: Project selection shows rich context preview | ✅ |
| **9. Add Migration Support for Existing Users** | | |
| | 1. Create migration utility for existing project files | ✅ |
| | 2. Add version detection for project file format | ✅ |
| | 3. Migrate existing view states to FilterStates format | ✅ |
| | 4. Add backward compatibility for older project files | ✅ |
| | 5. Add migration progress feedback and error handling | ✅ |
| | **Checkpoint**: Existing users can upgrade seamlessly | ✅ |
| **10. Comprehensive Testing and Validation** | | |
| | 1. Create unit tests for backend project context APIs | ✅ |
| | 2. Create tests for ViewContext analytical state persistence | ✅ |
| | 3. Create tests for project switching with context restoration | ✅ |
| | 4. Create tests for file operations with complete context | ✅ |
| | 5. Create integration tests for end-to-end workflows | ✅ |
| | 6. Create performance tests for state persistence | ✅ |
| | **Checkpoint**: All functionality covered by comprehensive tests | ✅ |

## Executive Summary
Based on our Project-Centric Architecture Analysis, we're implementing full integration between the rich backend FilterStates system and frontend ViewContext. The backend already stores comprehensive project context - we need to bridge this with the frontend's memory-only React state for analytical persistence.

## Design Principles
- **Analytical State**: Sorting and filtering persist to backend FilterStates
- **Navigational State**: Pagination remains memory-only for fresh starts  
- **Project Context**: Working context stored in Project structs, not global prefs
- **Clean Separation**: AppPreferences focused only on global UI settings

## Implementation Strategy

### Phase 1: Backend Foundation (Tasks 1)
- Leverage existing FilterStates infrastructure for analytical persistence
- Add project context APIs for view state management  
- Ensure robust error handling and state validation
- Update Wails bindings for frontend integration

### Phase 2: Frontend Integration (Tasks 2-4)
- Bridge ViewContext with backend FilterStates for sorting/filtering
- Keep pagination memory-only for fresh start user experience
- Update useActiveProject hook for project-centric data flow
- Add comprehensive error handling for state operations

### Phase 3: Context Restoration (Tasks 3, 5)
- Implement complete project context restoration on switching
- Add view navigation restoration for seamless project reopening
- Enhance file operations for full analytical state restoration
- Ensure pagination always starts fresh at page 1

### Phase 4: Polish and Performance (Tasks 6-10)
- Clean up global preferences to focus on UI settings only
- Add performance optimizations for state persistence
- Enhance UX with context previews and loading feedback
- Add migration support and comprehensive testing

## Critical Integration Points

### ViewContext → Backend FilterStates
```typescript
// Sorting and filtering persist to backend
const updateSorting = (viewStateKey: ViewStateKey, sortSpec: SortSpec) => {
  setViewSorting(prev => ({ ...prev, [key]: sortSpec }));
  SetFilterState(viewStateKey, { sorting: sortSpec });
};

// Pagination remains memory-only
const updatePagination = (viewStateKey: ViewStateKey, changes: Partial<PaginationState>) => {
  setViewPagination(prev => ({ ...prev, [key]: newState }));
  // No backend persistence - fresh start on project open
};
```

### Project Context Restoration Flow
1. **File → Open** triggers project loading
2. **Backend**: Load project with FilterStates and working context  
3. **Frontend**: Restore analytical state (sorting/filtering) from FilterStates
4. **Navigation**: Redirect to project's `LastView` if available
5. **Pagination**: Always start at page 1 for user clarity

### useActiveProject Architecture 
```typescript
// Change from global preferences to project-centric
const useActiveProject = () => {
  const project = useCurrentProject(); // From active project, not global store
  
  return {
    activeAddress: project?.workingContext?.primaryAddress,
    activeChain: project?.workingContext?.activeChain,
    setActiveAddress: (addr) => updateProjectContext({primaryAddress: addr}),
  };
};
```

## Dependencies and Prerequisites

### Existing Foundation (Already Available)
- ✅ Backend FilterStates infrastructure in Project model
- ✅ ViewStateKey system for state organization  
- ✅ Project Manager with multi-project support
- ✅ File operations with comprehensive error handling
- ✅ ViewContext with React state management
- ✅ Wails bindings and auto-generation system

### Key Design Constraints
- **Memory-only pagination**: Users expect fresh start at page 1
- **Analytical persistence**: Sorting/filtering maintain research context
- **Project isolation**: Each project has independent state
- **Performance**: Debounced saves, cached access, lazy loading
- **Backward compatibility**: Existing project files must work

## Risk Mitigation

### Technical Risks
- **State synchronization**: Comprehensive error handling for backend failures
- **Performance impact**: Debounced saves and intelligent caching
- **Data migration**: Gradual migration with fallback mechanisms
- **Type safety**: Maintain strict TypeScript throughout integration

### User Experience Risks  
- **Context confusion**: Clear visual feedback for project context loading
- **Data loss**: Atomic operations and state validation
- **Navigation disruption**: Preserve existing user workflows
- **Learning curve**: Intuitive defaults and helpful error messages

## Success Criteria

### Technical Objectives
- ✅ Analytical state (sorting/filtering) persists across app restarts
- ✅ Pagination resets to page 1 for fresh project opening experience
- ✅ Project switching restores complete working context
- ✅ Performance remains responsive with optimized state operations
- ✅ Comprehensive test coverage for all new functionality

### User Experience Goals
- ✅ Seamless project switching with preserved research context
- ✅ Intuitive fresh start navigation when opening projects
- ✅ Rich project selection with context preview
- ✅ Complete working context restoration (addresses, chains, views)
- ✅ Visual feedback for all project state operations

## Future Enhancement Opportunities

### Advanced Project Features
- Project templates for common analysis workflows
- Project sharing and collaboration capabilities  
- Project analytics and usage insights
- Integration with external research tools

### Enhanced Context Management
- Smart defaults based on project type detection
- Auto-categorization of addresses and contracts
- Machine learning for optimal view arrangements
- Advanced filtering with saved query templates

### Enterprise Capabilities
- Organization-wide project sharing
- Role-based access control for sensitive projects
- Compliance and audit trail capabilities
- Enterprise data connectors and integrations

## Development Guidelines

### Code Style and Standards
- **YARN ONLY**: Never use npm or npx - always `yarn` from repo root
- **Wails Dev Mode**: Always use `yarn start` (Wails dev mode), never browser mode
- **Logging**: Use `Log` from `@utils`, never console.log (invisible in Wails)
- **TypeScript**: No `any` types, no React imports (implicitly available)
- **Error Handling**: Use existing patterns (types.LoadState enum)
- **Components**: Follow established patterns (BaseTab, Table components)
- **Imports**: Use @models, @components, @utils, @hooks established aliases

### Testing and Validation
- **Read files first**: Always read current file contents before editing
- **Use existing patterns**: Follow DataFacet enums, ViewStateKey architecture
- **Run linter**: Use `yarn lint` from project root
- **Test together**: `yarn lint && yarn test && yarn start` for validation
- **Stop on failures**: Don't fix errors - report and await guidance

### Wails Integration
- **Regenerate bindings**: Use `wails generate module` after backend changes
- **Auto-generated types**: Import from frontend/wailsjs/go/models.ts
- **Error handling**: Backend functions return Go errors properly handled
- **Event system**: Use existing manager:change event patterns
