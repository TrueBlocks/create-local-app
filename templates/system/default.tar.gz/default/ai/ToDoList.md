# ToDoList: Fix AppPreferences Corruption Issue

## Active Tasks

| Task | Step | Done |
|:-----|:-----|:---:|
| 1. Add immediate protection against AppPreferences corruption | 1. Add validation to `SetAppPreferences` in `/pkg/preferences/app_prefs.go` to reject empty critical fields | ✅ |
| | 2. Add auto-repair logic to `GetAppPreferences` to detect and fix corrupted preferences | ✅ |
| | 3. Create backup of corrupted files before repair | ✅ |
| | 4. **Checkpoint**: Verify protection prevents further corruption | ✅ |
| 2. Fix test environment isolation | 1. Add `SetConfigBaseForTest` calls to all preference tests in `/app/preferences_test.go` | ✅ |
| | 2. Ensure tests use temporary directories and don't touch real config files | ✅ |
| | 3. Add cleanup in test teardown to remove accidentally created files | ✅ |
| | 4. **Checkpoint**: Verify tests don't affect real preference files | ✅ |
| 3. Fix all test files using empty AppPreferences structs | 1. Replace `preferences.AppPreferences{}` with `*preferences.NewAppPreferences()` in `/app/preferences_test.go` | ✅ |
| | 2. Replace empty structs in `/app/project_test.go` and other test files | ✅ |
| | 3. Create test helper function for creating valid test App instances | ✅ |
| | 4. Update all tests to use proper defaults instead of empty structs | ✅ |
| | 5. **Checkpoint**: Verify all tests use proper defaults | ✅ |
| 4. Fix TypeScript createFrom method safety | 1. Update `AppPreferences.createFrom` in frontend models to use defaults when source is empty | ✅ |
| | 2. Add validation in frontend before calling `SetAppPreferences` | ✅ |
| | 3. Ensure TypeScript preference operations preserve defaults | ✅ |
| | 4. **Checkpoint**: Verify frontend doesn't create corrupted preferences | ✅ |
| 5. Add comprehensive logging and monitoring | 1. Add logging to all `SetAppPreferences` calls to track changes | ✅ |
| | 2. Add logging when corruption is detected and repaired | ✅ |
| | 3. Add logging in preference update patterns to trace corruption sources | ✅ |
| | 4. **Checkpoint**: Verify logging helps identify any remaining issues | ✅ |
| 6. Add enhanced validation system | 1. Implement schema validation for preferences structure | ✅ |
| | 2. Add version-based migration system for preferences | ✅ |
| | 3. Create more comprehensive default value handling | ✅ |
| | 4. **Checkpoint**: Verify enhanced validation catches edge cases | ✅ |
| 7. Create debugging and diagnostic tools | 1. Add preference debugging commands for troubleshooting | ✅ |
| | 2. Implement preference history/audit trail system | ✅ |
| | 3. Create tools to diagnose and report corruption sources | ✅ |
| | 4. **Checkpoint**: Verify diagnostic tools help prevent future issues | ✅ |
| 8. Final integration testing | 1. Test preference persistence across app restarts | ✅ |
| | 2. Test corruption recovery scenarios work correctly | ✅ |
| | 3. Verify all preference update paths maintain proper defaults | ✅ |
| | 4. Test that `detailCollapsed` defaults to `true` and bounds are properly calculated | ✅ |
| | 5. **Checkpoint**: Full system test with corruption protection active | ✅ |

## Implementation Notes

### Error Handling Strategy
- Always backup corrupted files before attempting repair
- Use conservative validation that only rejects obviously invalid data
- Provide clear error messages and fallback to defaults
- Log all corruption detection and repair attempts

### Testing Strategy
- Ensure test isolation prevents affecting real preference files
- Test all corruption scenarios and recovery paths
- Verify defaults are properly applied in all cases
- Test preference persistence and migration scenarios

### Validation Rules
- `version` field must not be empty
- `detailCollapsed` should default to `true`
- `bounds` should have valid screen coordinates (not all zeros)
- `lastTheme` should default to "dark"
- `recentProjects` should be valid array (not null/undefined)

## Completed Tasks

None yet.
