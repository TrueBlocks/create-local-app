# IMPROVED ViewConfig Migration ToDoList

Based on lessons learned from Chunks migration and debugging the "dashboard" facet error.

## BULLETPROOF MIGRATION CHECKLIST

---

## ViewConfig/FacetConfig/FieldConfig Refactor & Flattening Plan (2025-08-12)

### Overview
This plan covers a major refactor to unify, flatten, and modernize the ViewConfig system for both backend and frontend. The goal is to:
- Remove redundancy (e.g., Accessor field)
- Flatten facet field definitions
- Add explicit ordering and enable/disable controls
- Support config file loading from disk (with embedded fallback)
- Ensure frontend/backend/test consistency and auto-generation

### Tasks

#### 1. Remove Redundant Accessor Field
- [ ] Remove `Accessor` from all `ColumnConfig` definitions and usages (backend, frontend, tests).
- [ ] Update all code to use only `Key` for data access.

#### 2. Add Explicit Order Fields
- [ ] Add `TableOrder` to each field in all `ColumnConfig` arrays.
- [ ] Add `DetailOrder` to each field in all `DetailPanelConfig.Fields` arrays.
- [ ] Ensure order is preserved in both table and detail views.

#### 3. Add getFacets Function and Facet Order
- [ ] Implement a file-level `getFacets` function in each config.go.
- [ ] This function returns both the `Facets` map and the `FacetOrder` array.
- [ ] Add an `Order` field to each facet for explicit ordering.

#### 4. Add Enable/Enabled Fields
- [ ] Add `Enabled` (default: true) to each FacetConfig.
- [ ] Add `Enable` (default: true) to each ViewConfig.
- [ ] Update UI to respect these fields for rendering.

#### 5. Flatten Facet Structures
- [ ] Replace `Columns` and `DetailPanels` with a single `Fields` array per facet.
- [ ] Each field should have all necessary metadata (order, section, label, formatter, etc.).
- [ ] Table and detail rendering should be derived from this unified list.

#### 6. Config File Loading from Disk
- [ ] On first run, read config from embedded filesystem and write to disk.
- [ ] On subsequent runs, load config from disk if present; otherwise, use embedded.
- [ ] Ensure this logic is robust and cross-platform.

#### 7. Frontend/Backend/Test Consistency
- [ ] Update all auto-generation scripts to match new structure.
- [ ] Update all frontend view files (`frontend/src/views/**/<View>.tsx`) to use new config shape.
- [ ] Update and expand backend and frontend tests to cover new structure and edge cases.
- [ ] Document migration steps and gotchas for future contributors.

### Anticipated Challenges
- Ensuring all views/facets are migrated consistently (auto-generation is critical)
- Avoiding regressions in UI rendering and data access
- Handling user-modified config files on disk (merging, validation)
- Keeping tests up-to-date and meaningful
- Coordinating changes across backend, frontend, and build tooling

### Migration Steps (High-Level)
1. Refactor backend types and config.go files (Accessor removal, order fields, flattening)
2. Update frontend TypeScript types and view rendering logic
3. Implement config file disk loading logic
4. Update auto-generation and test scripts
5. Test all views/facets thoroughly (manual and automated)
6. Document the new system and migration process

---

### **PRE-STEP 0: Analyze Existing View Structure** 🔍
- [ ] **Check existing ViewConfig backend structure**: Look at `pkg/types/<view>/config.go` to understand current field names and types
- [ ] **Analyze facets.ts**: Record all facets and their labels/properties  
- [ ] **Analyze columns.ts**: Record all column configurations and which facets use them
- [ ] **Analyze detailPanels.ts**: Record all detail panel configurations, sections, field mappings, and collapsed states
- [ ] **Check View.tsx for isForm usage**: Identify which facets are forms vs tables by looking for `isForm(facet)` function
- [ ] **Document dependencies**: Note any special imports, utilities, or complex logic that needs migration

## **PHASE 1: Backend Implementation**

### **Step 1: Create/Update Backend ViewConfig** 
- [ ] **Check existing config.go structure**: Verify field names match `types.ViewConfig` exactly
- [ ] **Implement GetConfig method** with all facets from facets.ts
- [ ] **Set IsForm correctly** based on analysis from View.tsx isForm function 
- [ ] **Migrate DetailPanels**: Convert all detailPanels.tsx configurations to `[]types.DetailPanelConfig`
  - [ ] Map section names to `Title` field
  - [ ] Map field configurations to `[]types.DetailFieldConfig` 
  - [ ] Convert `detailFormat` to `Formatter` field
  - [ ] Preserve collapsed states and field ordering
- [ ] **Set Columns to nil**: Leave columns as `nil` for now (will be handled by frontend)
- [ ] **Test backend compilation**: `go build ./pkg/types/<view>`

### **Step 2: Add API Method**
- [ ] **Add Get<View>Config method** to `app/api_<view>.go` following exact pattern:
  ```go
  func (a *App) Get<View>Config(payload *types.Payload, row any) (*types.ViewConfig, error) {
    return <view>.Get<View>Collection().GetConfig(payload, row)
  }
  ```
- [ ] **Test API compilation**: `go build ./app`

### **Step 3: Update Frontend Hook**
- [ ] **Add Get<View>Config import** to `frontend/src/hooks/useViewConfig.ts`
- [ ] **Add case to switch statement**: `case '<view>': result = await Get<View>Config(currentPayload, currentRow); break;`
- [ ] **Regenerate Wails bindings**: `wails generate module`
- [ ] **Test frontend compilation**: `yarn lint`

## **PHASE 2: Frontend Integration**

### **Step 4: Update View Component**
- [ ] **Add useViewConfig import** to the View component
- [ ] **Add ViewConfig hook call** following Status pattern:
  ```tsx
  const { config: viewConfig } = useViewConfig({
    viewName: '<view>',
    payload: createPayload(types.DataFacet.<DEFAULT_FACET>),
    row: undefined,
  });
  ```

### **Step 5: Replace Static Facets**
- [ ] **Replace facets import** with ViewConfig-generated facets using Status pattern:
  ```tsx
  const facetsFromConfig = useMemo((): DataFacetConfig[] => {
    if (!viewConfig?.facets) {
      // Fallback to default facets if ViewConfig not loaded yet
      return [/* explicit fallback facets from original facets.ts */];
    }
    return Object.entries(viewConfig.facets).map(([facetId, facetConfig]) => ({
      id: facetId as types.DataFacet,
      label: facetConfig.name || facetId,
    }));
  }, [viewConfig?.facets]);
  ```
- [ ] **Update useActiveFacet call**: Use `facetsFromConfig` directly

### **Step 6: Replace Static Columns**
- [ ] **Replace useColumns call** to use ViewConfig:
  ```tsx
  const currentColumns = useColumns(
    viewConfig?.facets?.[getCurrentDataFacet()]?.columns || [],
    // ... rest of config
  );
  ```
- [ ] **Handle FormView columns**: For form facets, either:
  - Add column configs to ViewConfig backend, OR  
  - Create inline form field definitions (for simple cases)

### **Step 7: Replace Static Detail Panels**
- [ ] **Remove detailPanels import**
- [ ] **Replace detailPanel prop** with ViewConfig:
  ```tsx
  detailPanel={createDetailPanelFromViewConfig(
    viewConfig,
    getCurrentDataFacet,
    '<View> Details'
  )}
  ```

### **Step 8: Handle Form Detection**
- [ ] **Replace static isForm function** with ViewConfig:
  ```tsx
  const isFormFacet = currentFacetConfig?.isForm || false;
  ```

## **PHASE 3: Testing & Cleanup**

### **Step 9: Integration Testing**  
- [ ] **Test compilation**: `yarn lint`
- [ ] **Test functionality**: `yarn test && yarn start`
- [ ] **Test all facets**: Navigate to each facet and verify:
  - [ ] Data loads without "dashboard" errors
  - [ ] Detail panels render correctly with proper sections/fields
  - [ ] Forms render correctly (if applicable)
  - [ ] Tables render correctly
- [ ] **Check console for errors**: No "unsupported dataFacet" or similar errors

### **Step 10: Static File Cleanup**
- [ ] **Verify no imports**: `grep -r "from.*<view>.*facets\|columns\|detailPanels" frontend/src/`
- [ ] **Remove static files**: `rm -f frontend/src/views/<view>/{facets.ts,columns.ts,detailPanels.tsx}`
- [ ] **Final test**: `yarn lint && yarn start`
- [ ] **Verify final structure**: 
  ```
  frontend/src/views/<view>/
  ├── <View>.tsx     # ✅ Fully migrated to ViewConfig  
  └── index.ts       # ✅ Simple export (preserved)
  ```

## **CRITICAL SUCCESS CRITERIA**

✅ **Backend has complete config**: All facets, isForm flags, and DetailPanels migrated  
✅ **No static imports**: View component imports nothing from static config files  
✅ **No dashboard errors**: ViewConfig loads before facets are used  
✅ **DetailPanels work**: All detail panel sections and fields render correctly  
✅ **Forms work**: Form facets render correctly with proper field definitions  
✅ **Static files removed**: Only <View>.tsx and index.ts remain in frontend  

## **LESSONS LEARNED**

1. **Dashboard Error Root Cause**: Empty facets array causes `useActiveFacet` to default to DASHBOARD facet
2. **Solution**: Always provide explicit fallback facets during ViewConfig loading (Status pattern)
3. **DetailPanels Migration**: Must capture ALL detail panel configurations including sections, field mappings, formatters, and collapsed states
4. **IsForm Detection**: Must analyze original View.tsx isForm function to set backend IsForm flags correctly
5. **Testing Pattern**: Always test for "unsupported dataFacet" errors which indicate ViewConfig loading issues

## **NEXT VIEWS TO MIGRATE**

Priority order based on complexity:
- [ ] **Contracts** (medium complexity, has forms and detail panels)
- [ ] **Exports** (high complexity, multiple forms and CRUD operations)
- [ ] **Names** (medium complexity, has forms and CRUD)  
- [ ] **Monitors** (already migrated ✅)
