# AI Folder

This folder contains prompts for AI model use in the project. We usually have the AI help us build a requirements document for a feature and then we use the RulesOfEngagment to turn those requirements into a to-do list. The AI then walks us through the ToDo list step by step until the feature is complete.
