package store

import (
	"github.com/{{ORG_NAME}}/{{SLUG}}/pkg/types"

	"{{CHIFRA}}/pkg/base"
)

type CollectionKey struct {
	Chain   string       // may be empty
	Address base.Address // may be empty
}

func GetCollectionKey(payload *types.Payload) CollectionKey {
	return CollectionKey{
		Chain:   payload.Chain,
		Address: base.HexToAddress(payload.Address)}
}
