package comparitoor

import (
	sdk "{{SDK}}"
)

// AnnotatedTransaction wraps sdk.Transaction with missing/unique flags for frontend rendering
type AnnotatedTransaction struct {
	sdk.Transaction
	Missing bool `json:"missing"`
	Unique  bool `json:"unique"`
}
