// Copyright 2016, 2026 The Authors. All rights reserved.
// Use of this source code is governed by a license that can
// be found in the LICENSE file.
/*
 * Parts of this file were auto generated. Edit only those parts of
 * the code inside of 'EXISTING_CODE' tags.
 */

package status

import "{{PACKAGES}}/types"

// GetConfig returns the ViewConfig for the Status view
func (c *StatusCollection) GetConfig() (*types.ViewConfig, error) {
	facets := c.buildStaticFacets()
	facetOrder := c.buildFacetOrder()

	cfg := &types.ViewConfig{
		ViewName:   "status",
		Facets:     facets,
		FacetOrder: facetOrder,
		Actions:    c.buildActions(),
	}

	types.DeriveFacets(cfg)
	types.SortFields(cfg)
	types.SetMenuOrder(cfg)
	return cfg, nil
}

func (c *StatusCollection) buildStaticFacets() map[string]types.FacetConfig {
	return map[string]types.FacetConfig{
		"status": {
			Name:          "Status",
			Store:         "status",
			ViewType:      "form",
			DividerBefore: false,
			Fields:        getStatusFields(),
			Actions:       []string{},
			HeaderActions: []string{},
		},
		"caches": {
			Name:          "Caches",
			Store:         "caches",
			ViewType:      "table",
			DividerBefore: false,
			Fields:        getCachesFields(),
			Actions:       []string{},
			HeaderActions: []string{"export"},
		},
		"chains": {
			Name:          "Chains",
			Store:         "chains",
			ViewType:      "table",
			DividerBefore: false,
			Fields:        getChainsFields(),
			Actions:       []string{},
			HeaderActions: []string{"export"},
		},
	}
}

func (c *StatusCollection) buildFacetOrder() []string {
	return []string{
		"status",
		"caches",
		"chains",
	}
}

func (c *StatusCollection) buildActions() map[string]types.ActionConfig {
	return map[string]types.ActionConfig{
		"export": {Name: "export", Label: "Export", Icon: "Export"},
	}
}

func getCachesFields() []types.FieldConfig {
	ret := []types.FieldConfig{
		{Section: "General", Key: "type", Type: "string"},
		{Section: "General", Key: "path", Type: "path"},
		{Section: "Statistics", Key: "nFiles", Type: "uint64"},
		{Section: "Statistics", Key: "nFolders", Type: "uint64"},
		{Section: "Statistics", Key: "sizeInBytes", Type: "uint64"},
		{Section: "Timestamps", Key: "lastCached", Type: "string"},
		{Section: "", Key: "actions", Type: "actions", NoDetail: true},
	}
	types.NormalizeFields(&ret)
	return ret
}

func getChainsFields() []types.FieldConfig {
	ret := []types.FieldConfig{
		{Section: "General", Key: "chain", Type: "string"},
		{Section: "General", Key: "chainId", Type: "uint64"},
		{Section: "General", Key: "symbol", Type: "string"},
		{Section: "Providers", Key: "rpcProvider", Type: "url"},
		{Section: "Providers", Key: "ipfsGateway", Type: "url"},
		{Section: "Explorers", Key: "localExplorer", Type: "url"},
		{Section: "Explorers", Key: "remoteExplorer", Type: "url"},
		{Section: "", Key: "actions", Type: "actions", NoDetail: true},
	}
	types.NormalizeFields(&ret)
	return ret
}

func getStatusFields() []types.FieldConfig {
	ret := []types.FieldConfig{
		{Section: "Paths", Key: "cachePath", Type: "path"},
		{Section: "Paths", Key: "indexPath", Type: "path"},
		{Section: "Chain", Key: "chain", Type: "string"},
		{Section: "Chain", Key: "chainId", Type: "uint64"},
		{Section: "Chain", Key: "networkId", Type: "string"},
		{Section: "Chain", Key: "chainConfig", Type: "path"},
		{Section: "Config", Key: "rootConfig", Type: "path"},
		{Section: "Config", Key: "clientVersion", Type: "string"},
		{Section: "Config", Key: "version", Type: "string"},
		{Section: "Progress", Key: "progress", Type: "string"},
		{Section: "Providers", Key: "rpcProvider", Type: "url"},
		{Section: "Flags", Key: "hasEsKey", Type: "boolean"},
		{Section: "Flags", Key: "hasPinKey", Type: "boolean"},
		{Section: "Flags", Key: "isApi", Type: "boolean"},
		{Section: "Flags", Key: "isArchive", Type: "boolean"},
		{Section: "Flags", Key: "isScraping", Type: "boolean"},
		{Section: "Flags", Key: "isTesting", Type: "boolean"},
		{Section: "Flags", Key: "isTracing", Type: "boolean"},
	}
	types.NormalizeFields(&ret)
	return ret
}

// EXISTING_CODE
// EXISTING_CODE
