// Copyright 2016, 2026 The Authors. All rights reserved.
// Use of this source code is governed by a license that can
// be found in the LICENSE file.
/*
 * Parts of this file were auto generated. Edit only those parts of
 * the code inside of 'EXISTING_CODE' tags.
 */

package status

// EXISTING_CODE
import (
	"fmt"
	"sync"

	"{{PACKAGES}}/logging"
	"{{PACKAGES}}/store"
	"{{PACKAGES}}/types"

	"{{CHIFRA}}/pkg/output"
	sdk "{{SDK}}"
)

type Cache = sdk.Cache
type Chain = sdk.Chain
type Status = sdk.Status

// EXISTING_CODE

var (
	cachesStore   = make(map[string]*store.Store[Cache])
	cachesStoreMu sync.Mutex

	chainsStore   = make(map[string]*store.Store[Chain])
	chainsStoreMu sync.Mutex

	statusStore   = make(map[string]*store.Store[Status])
	statusStoreMu sync.Mutex
)

func (c *StatusCollection) getCachesStore(payload *types.Payload, facet types.DataFacet) *store.Store[Cache] {
	cachesStoreMu.Lock()
	defer cachesStoreMu.Unlock()

	// EXISTING_CODE
	// EXISTING_CODE

	storeKey := getStoreKey(payload)
	theStore := cachesStore[storeKey]
	if theStore == nil {
		queryFunc := func(ctx *output.RenderCtx) error {
			// EXISTING_CODE
			opts := sdk.StatusOptions{
				Globals:   sdk.Globals{Chain: payload.ActiveChain},
				RenderCtx: ctx,
			}
			if _, _, err := opts.StatusCaches(); err != nil {
				wrappedErr := types.NewSDKError("status", StatusCaches, "fetch", err)
				logging.LogBEWarning(fmt.Sprintf("Status Caches SDK query error: %v", wrappedErr))
				return wrappedErr
			}
			// EXISTING_CODE
			return nil
		}

		processFunc := func(item interface{}) *Cache {
			// EXISTING_CODE
			// EXISTING_CODE
			if it, ok := item.(*Cache); ok {
				return it
			}
			return nil
		}

		mappingFunc := func(item *Cache) (key interface{}, includeInMap bool) {
			// EXISTING_CODE
			// EXISTING_CODE
			return nil, false
		}

		storeName := c.GetStoreName(payload, facet)
		theStore = store.NewStore(storeName, queryFunc, processFunc, mappingFunc)

		// EXISTING_CODE
		// EXISTING_CODE

		cachesStore[storeKey] = theStore
	}

	return theStore
}

func (c *StatusCollection) getChainsStore(payload *types.Payload, facet types.DataFacet) *store.Store[Chain] {
	chainsStoreMu.Lock()
	defer chainsStoreMu.Unlock()

	// EXISTING_CODE
	// EXISTING_CODE

	storeKey := getStoreKey(payload)
	theStore := chainsStore[storeKey]
	if theStore == nil {
		queryFunc := func(ctx *output.RenderCtx) error {
			// EXISTING_CODE
			opts := sdk.StatusOptions{
				Globals:   sdk.Globals{Chain: payload.ActiveChain},
				RenderCtx: ctx,
			}
			if _, _, err := opts.StatusChains(); err != nil {
				wrappedErr := types.NewSDKError("status", StatusChains, "fetch", err)
				logging.LogBEWarning(fmt.Sprintf("Status Chains SDK query error: %v", wrappedErr))
				return wrappedErr
			}
			// EXISTING_CODE
			return nil
		}

		processFunc := func(item interface{}) *Chain {
			// EXISTING_CODE
			// EXISTING_CODE
			if it, ok := item.(*Chain); ok {
				return it
			}
			return nil
		}

		mappingFunc := func(item *Chain) (key interface{}, includeInMap bool) {
			// EXISTING_CODE
			// EXISTING_CODE
			return nil, false
		}

		storeName := c.GetStoreName(payload, facet)
		theStore = store.NewStore(storeName, queryFunc, processFunc, mappingFunc)

		// EXISTING_CODE
		// EXISTING_CODE

		chainsStore[storeKey] = theStore
	}

	return theStore
}

func (c *StatusCollection) getStatusStore(payload *types.Payload, facet types.DataFacet) *store.Store[Status] {
	statusStoreMu.Lock()
	defer statusStoreMu.Unlock()

	// EXISTING_CODE
	// EXISTING_CODE

	storeKey := getStoreKey(payload)
	theStore := statusStore[storeKey]
	if theStore == nil {
		queryFunc := func(ctx *output.RenderCtx) error {
			// EXISTING_CODE
			opts := sdk.StatusOptions{
				Globals:   sdk.Globals{Chain: payload.ActiveChain},
				RenderCtx: ctx,
			}
			if _, _, err := opts.StatusHealthcheck(); err != nil {
				wrappedErr := types.NewSDKError("status", StatusStatus, "fetch", err)
				logging.LogBEWarning(fmt.Sprintf("Status Healthcheck SDK query error: %v", wrappedErr))
				return wrappedErr
			}
			// EXISTING_CODE
			return nil
		}

		processFunc := func(item interface{}) *Status {
			// EXISTING_CODE
			// EXISTING_CODE
			if it, ok := item.(*Status); ok {
				return it
			}
			return nil
		}

		mappingFunc := func(item *Status) (key interface{}, includeInMap bool) {
			// EXISTING_CODE
			// EXISTING_CODE
			return nil, false
		}

		storeName := c.GetStoreName(payload, facet)
		theStore = store.NewStore(storeName, queryFunc, processFunc, mappingFunc)

		// EXISTING_CODE
		// EXISTING_CODE

		statusStore[storeKey] = theStore
	}

	return theStore
}

func (c *StatusCollection) GetStoreName(payload *types.Payload, facet types.DataFacet) string {
	name := ""
	switch facet {
	case StatusStatus:
		name = "status-status"
	case StatusCaches:
		name = "status-caches"
	case StatusChains:
		name = "status-chains"
	default:
		return ""
	}
	name = fmt.Sprintf("%s-%s-%s", name, payload.ActiveChain, payload.ActiveAddress)
	return name
}

var (
	collections   = make(map[store.CollectionKey]*StatusCollection)
	collectionsMu sync.Mutex
)

func GetStatusCollection(payload *types.Payload) *StatusCollection {
	collectionsMu.Lock()
	defer collectionsMu.Unlock()

	pl := *payload
	key := store.GetCollectionKey(&pl)
	if collection, exists := collections[key]; exists {
		return collection
	}

	collection := NewStatusCollection(payload)
	collections[key] = collection
	return collection
}

func getStoreKey(payload *types.Payload) string {
	// EXISTING_CODE
	if payload.DataFacet == StatusChains {
		return "singleton"
	}
	// EXISTING_CODE
	return payload.ActiveChain
}

// EXISTING_CODE
// EXISTING_CODE
