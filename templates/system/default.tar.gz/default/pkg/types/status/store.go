// Copyright 2016, 2026 The Authors. All rights reserved.
// Use of this source code is governed by a license that can
// be found in the LICENSE file.
/*
 * Parts of this file were auto generated. Edit only those parts of
 * the code inside of 'EXISTING_CODE' tags.
 */

package status

// EXISTING_CODE
import (
	"fmt"
	"sync"

	"{{PACKAGES}}/logging"
	"{{PACKAGES}}/store"
	"{{PACKAGES}}/types"

	"github.com/{{ORG_NAME}}/{{ORG_LOWER}}-chifra/v6/pkg/output"
	sdk "github.com/{{ORG_NAME}}/{{ORG_LOWER}}-sdk/v6"
)

type Cache = sdk.Cache
type Chain = sdk.Chain
type Status = sdk.Status

// EXISTING_CODE

var (
	cachesStore   = make(map[string]*store.Store[Cache])
	cachesStoreMu sync.Mutex

	chainsStore   = make(map[string]*store.Store[Chain])
	chainsStoreMu sync.Mutex

	statusStore   = make(map[string]*store.Store[Status])
	statusStoreMu sync.Mutex
)

func (c *StatusCollection) getCachesStore(payload *types.Payload, facet types.DataFacet) *store.Store[Cache] {
	cachesStoreMu.Lock()
	defer cachesStoreMu.Unlock()

	// EXISTING_CODE
	// EXISTING_CODE

	storeKey := getStoreKey(payload)
	theStore := cachesStore[storeKey]
	if theStore == nil {
		queryFunc := func(ctx *output.RenderCtx) error {
			// EXISTING_CODE
			opts := sdk.StatusOptions{
				Globals:   sdk.Globals{Chain: payload.ActiveChain},
				RenderCtx: ctx,
			}
			if _, _, err := opts.StatusCaches(); err != nil {
				wrappedErr := types.NewSDKError("status", StatusCaches, "fetch", err)
				logging.LogBEWarning(fmt.Sprintf("Status Caches SDK query error: %v", wrappedErr))
				return wrappedErr
			}
			// EXISTING_CODE
			return nil
		}

		processFunc := func(item interface{}) *Cache {
			if it, ok := item.(*Cache); ok {
				// EXISTING_CODE
				// EXISTING_CODE
				return it
			}
			return nil
		}

		mappingFunc := func(item *Cache) (key string, includeInMap bool) {
			return "", false
		}

		storeName := c.getStoreName(payload, facet)
		theStore = store.NewStore(storeName, queryFunc, processFunc, mappingFunc)

		// EXISTING_CODE
		// EXISTING_CODE

		cachesStore[storeKey] = theStore
	}

	return theStore
}

func (c *StatusCollection) getChainsStore(payload *types.Payload, facet types.DataFacet) *store.Store[Chain] {
	chainsStoreMu.Lock()
	defer chainsStoreMu.Unlock()

	// EXISTING_CODE
	// EXISTING_CODE

	storeKey := getStoreKey(payload)
	theStore := chainsStore[storeKey]
	if theStore == nil {
		queryFunc := func(ctx *output.RenderCtx) error {
			// EXISTING_CODE
			opts := sdk.StatusOptions{
				Globals:   sdk.Globals{Chain: payload.ActiveChain},
				RenderCtx: ctx,
			}
			if _, _, err := opts.StatusChains(); err != nil {
				wrappedErr := types.NewSDKError("status", StatusChains, "fetch", err)
				logging.LogBEWarning(fmt.Sprintf("Status Chains SDK query error: %v", wrappedErr))
				return wrappedErr
			}
			// EXISTING_CODE
			return nil
		}

		processFunc := func(item interface{}) *Chain {
			if it, ok := item.(*Chain); ok {
				// EXISTING_CODE
				// EXISTING_CODE
				return it
			}
			return nil
		}

		mappingFunc := func(item *Chain) (key string, includeInMap bool) {
			return "", false
		}

		storeName := c.getStoreName(payload, facet)
		theStore = store.NewStore(storeName, queryFunc, processFunc, mappingFunc)

		// EXISTING_CODE
		// EXISTING_CODE

		chainsStore[storeKey] = theStore
	}

	return theStore
}

func (c *StatusCollection) getStatusStore(payload *types.Payload, facet types.DataFacet) *store.Store[Status] {
	statusStoreMu.Lock()
	defer statusStoreMu.Unlock()

	// EXISTING_CODE
	// EXISTING_CODE

	storeKey := getStoreKey(payload)
	theStore := statusStore[storeKey]
	if theStore == nil {
		queryFunc := func(ctx *output.RenderCtx) error {
			// EXISTING_CODE
			opts := sdk.StatusOptions{
				Globals:   sdk.Globals{Chain: payload.ActiveChain},
				RenderCtx: ctx,
			}
			if _, _, err := opts.StatusHealthcheck(); err != nil {
				wrappedErr := types.NewSDKError("status", StatusStatus, "fetch", err)
				logging.LogBEWarning(fmt.Sprintf("Status Healthcheck SDK query error: %v", wrappedErr))
				return wrappedErr
			}
			// EXISTING_CODE
			return nil
		}

		processFunc := func(item interface{}) *Status {
			if it, ok := item.(*Status); ok {
				// EXISTING_CODE
				// EXISTING_CODE
				return it
			}
			return nil
		}

		mappingFunc := func(item *Status) (key string, includeInMap bool) {
			return "", false
		}

		storeName := c.getStoreName(payload, facet)
		theStore = store.NewStore(storeName, queryFunc, processFunc, mappingFunc)

		// EXISTING_CODE
		// EXISTING_CODE

		statusStore[storeKey] = theStore
	}

	return theStore
}

func (c *StatusCollection) getStoreName(payload *types.Payload, facet types.DataFacet) string {
	name := ""

	// EXISTING_CODE
	// EXISTING_CODE

	switch facet {
	case StatusStatus:
		name = "status-status"
	case StatusCaches:
		name = "status-caches"
	case StatusChains:
		name = "status-chains"
	default:
		return ""
	}
	name = fmt.Sprintf("%s-%s-%s", name, payload.ActiveChain, payload.ActiveAddress)
	return name
}

var (
	collections   = make(map[string]*StatusCollection)
	collectionsMu sync.Mutex
)

func GetStatusCollection(payload *types.Payload) *StatusCollection {
	collectionsMu.Lock()
	defer collectionsMu.Unlock()

	pl := *payload
	key := getStoreKey(&pl)
	if collection, exists := collections[key]; exists {
		return collection
	}

	collection := NewStatusCollection(payload)
	collections[key] = collection
	return collection
}

func getStoreKey(payload *types.Payload) string {
	// EXISTING_CODE
	if payload.DataFacet == StatusChains {
		return "singleton"
	}
	// EXISTING_CODE
	return payload.ActiveChain
}

// EXISTING_CODE
// EXISTING_CODE
