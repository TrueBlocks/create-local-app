package chunks

func (c *ChunksCollection) updateManifestBucket(manifest *Manifest) {
	_ = manifest
}
