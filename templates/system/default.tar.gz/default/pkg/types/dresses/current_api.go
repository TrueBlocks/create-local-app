package dresses

import (
	dalle "{{DALLE}}"
	"{{DALLE}}/pkg/model"
	"{{DALLE}}/pkg/progress"
)

func GetCurrentDressFor(series, address string) *model.DalleDress {
	if address == "" {
		return &model.DalleDress{}
	}
	if series == "" {
		series = "empty"
	}
	// Always attempt generation (cached path is fast if image exists)
	_, _ = dalle.GenerateAnnotatedImage(series, address, false, 0)
	if pr := progress.GetProgress(series, address); pr != nil && pr.DalleDress != nil {
		dd := *pr.DalleDress
		if dd.AnnotatedPath != "" {
			dd.Completed = true
			if pr.CacheHit {
				dd.CacheHit = true
			}
		}
		return &dd
	}
	return &model.DalleDress{}
}
