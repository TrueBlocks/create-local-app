package project

import sdk "github.com/{{ORG_NAME}}/{{ORG_LOWER}}-sdk/v6"

func SortProjects(a []Project, sortSpec sdk.SortSpec) error {
	_ = a
	_ = sortSpec
	return nil // TODO: do something here
}
