// Copyright 2016, 2026 The Authors. All rights reserved.
// Use of this source code is governed by a license that can
// be found in the LICENSE file.
/*
 * Parts of this file were auto generated. Edit only those parts of
 * the code inside of 'EXISTING_CODE' tags.
 */
package main

import (
	"embed"
	"fmt"

	"{{APP}}"
	"{{PACKAGES}}/msgs"
	"{{PACKAGES}}/preferences"
	"{{PACKAGES}}/project"
	"{{PACKAGES}}/types"
	"{{PACKAGES}}/types/abis"
	"{{PACKAGES}}/types/chunks"
	"{{PACKAGES}}/types/comparitoor"
	"{{PACKAGES}}/types/contracts"
	"{{PACKAGES}}/types/dresses"
	"{{PACKAGES}}/types/exports"
	"{{PACKAGES}}/types/monitors"
	"{{PACKAGES}}/types/names"
	"{{PACKAGES}}/types/status"
	//
	"github.com/wailsapp/wails/v2"
	wLogger "github.com/wailsapp/wails/v2/pkg/logger"
	"github.com/wailsapp/wails/v2/pkg/options"
	"github.com/wailsapp/wails/v2/pkg/options/assetserver"
)

//go:embed frontend/dist/* frontend/src/assets/help/* frontend/src/assets/views/* wails.json .create-local-app.json
var assets embed.FS

func main() {
	preferences.LoadIdentifiers(assets)
	a, menu := app.NewApp(assets)

	opts := options.App{
		Title:         preferences.GetAppId().AppName,
		Width:         1024,
		Height:        768,
		Menu:          menu,
		StartHidden:   true,
		OnStartup:     a.Startup,
		OnDomReady:    a.DomReady,
		OnBeforeClose: a.BeforeClose,
		LogLevel:      wLogger.INFO,
		AssetServer: &assetserver.Options{
			Assets: assets,
		},
		BackgroundColour: &options.RGBA{R: 27, G: 38, B: 54, A: 1},
		Bind: []interface{}{
			a,
			&project.Project{},
			&exports.ExportsCollection{},
			&monitors.MonitorsCollection{},
			&abis.AbisCollection{},
			&names.NamesCollection{},
			&chunks.ChunksCollection{},
			&contracts.ContractsCollection{},
			&status.StatusCollection{},
			&dresses.DressesCollection{},
			&comparitoor.ComparitoorCollection{},
		},
		EnumBind: []interface{}{
			msgs.AllMessages,
			types.AllDataFacets,
			types.AllCruds,
			types.AllStates,
			types.AllPeriods,
		},
	}

	if err := wails.Run(&opts); err != nil {
		fmt.Println("Error:", err.Error())
	}
}
