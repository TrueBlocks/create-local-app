export * from './detailPanel';
