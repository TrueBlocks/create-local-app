import { useCallback, useMemo, useState } from 'react';

import { DressesCrud, Reload } from '@app';
import {
  BaseTab,
  ConfirmModal,
  RendererParams,
  createDetailPanel,
} from '@components';
import {
  useFacetColumns,
  usePayload,
  useSilencedDialog,
  useViewConfig,
} from '@hooks';
import { crud, dresses, model, project, types } from '@models';
import { useErrorHandler } from '@utils';

import { getItemKey, useGalleryStore } from '../../store/useGalleryStore';

export const SeriesFacet = ({ params }: { params: RendererParams }) => {
  const { data } = params;
  const pageData = useMemo(
    () =>
      ({
        series: data || [],
      }) as unknown as dresses.DressesPage,
    [data],
  );
  const viewStateKey: project.ViewStateKey = useMemo(
    () => ({
      viewName: 'dresses',
      facetName: types.DataFacet.SERIES,
    }),
    [],
  );

  // Use hooks for required functionality
  const createPayload = usePayload('dresses');
  const galleryState = useGalleryStore();
  const { handleError } = useErrorHandler();

  // Mock fetchData for now
  const fetchData = useCallback(async () => {
    // TODO: Implement actual fetch when renderer pattern supports it
  }, []);
  // Check if series removal dialog is silenced
  const seriesRemoveSilencedDialog = useSilencedDialog('confirm.removeSeries');

  // State for custom series removal confirmation
  const [seriesRemoveConfirm, setSeriesRemoveConfirm] = useState<{
    opened: boolean;
    suffix: string;
  }>({ opened: false, suffix: '' });

  // Helper function to refresh gallery cache
  const refreshGalleryCache = useCallback(async () => {
    try {
      // Force gallery cache refresh by calling reload on gallery facet
      await Reload(createPayload(types.DataFacet.GALLERY));
    } catch {
      // TODO: handle error if needed
    }
  }, [createPayload]);

  // Helper function to handle selected series management
  const handleSelectedSeriesUpdate = useCallback(
    async (affectedSuffix: string, operation: crud.Operation) => {
      try {
        // Get currently selected dresses from gallery store
        const selectedItem = galleryState.getSelectedItem();
        if (!selectedItem) {
          return;
        }

        // Check if the selected dresses belongs to the affected series
        if (selectedItem.series !== affectedSuffix) {
          return;
        }

        // If selected dresses series was deleted or removed, select a reasonable alternative
        if (
          operation === crud.Operation.DELETE ||
          operation === crud.Operation.REMOVE
        ) {
          // Get all available dresseses from the gallery
          const allDresses = galleryState.galleryItems || [];

          // Find first dresses from a non-deleted series that isn't the affected one
          const availableDresses = allDresses.filter((d: model.DalleDress) => {
            const dressesSeries = pageData?.series?.find(
              (s) => s.suffix === d.series,
            );
            return (
              dressesSeries &&
              !dressesSeries.deleted &&
              d.series !== affectedSuffix
            );
          });

          if (availableDresses.length > 0 && availableDresses[0]) {
            const newSelection = availableDresses[0];
            const newKey = getItemKey(newSelection);

            // Update gallery selection
            galleryState.setSelection(newKey, viewStateKey);
          } else {
            // Clear selection if no alternatives available
            galleryState.clearSelection(viewStateKey);
          }
        }
      } catch {
        // TODO: handle error if needed
      }
    },
    [galleryState, pageData, viewStateKey],
  );

  const performSeriesRemove = useCallback(
    async (suffix: string) => {
      if (!suffix) return;

      try {
        await DressesCrud(
          createPayload(types.DataFacet.SERIES),
          crud.Operation.REMOVE,
          { suffix },
        );
        // Refresh data first, then cache, then handle selection
        await fetchData();
        await refreshGalleryCache();
        await handleSelectedSeriesUpdate(suffix, crud.Operation.REMOVE);
      } catch (err) {
        handleError(err, 'Remove operation failed');
      }
    },
    [
      createPayload,
      fetchData,
      handleError,
      refreshGalleryCache,
      handleSelectedSeriesUpdate,
    ],
  );

  // Series toggle handler for delete/undelete operations
  const handleSeriesToggle = useCallback(
    async (suffix: string) => {
      try {
        // Find the current series to check its deleted state
        const currentSeries = pageData?.series?.find(
          (s) => s.suffix === suffix,
        );
        if (!currentSeries) {
          return;
        }

        const isCurrentlyDeleted = Boolean(currentSeries.deleted);
        const operation = isCurrentlyDeleted
          ? crud.Operation.UNDELETE
          : crud.Operation.DELETE;

        await DressesCrud(createPayload(types.DataFacet.SERIES), operation, {
          suffix,
        });

        // Force a complete data refresh FIRST
        await fetchData();

        // Then invalidate gallery cache to ensure UI updates
        await refreshGalleryCache();

        // Finally handle selected item management with fresh data
        await handleSelectedSeriesUpdate(suffix, operation);

        // Also try to force a reload from the backend
        await Reload(createPayload(types.DataFacet.SERIES));

        // Fetch data again after reload
        await fetchData();
      } catch (err) {
        handleError(err, 'Toggle operation failed');
      }
    },
    [
      createPayload,
      fetchData,
      handleError,
      pageData,
      refreshGalleryCache,
      handleSelectedSeriesUpdate,
    ],
  );

  // Series remove handler with confirmation dialog logic
  const handleSeriesRemove = useCallback(
    async (suffix: string) => {
      // Check if dialog is silenced - if so, proceed directly
      if (
        seriesRemoveSilencedDialog.isSilenced &&
        !seriesRemoveSilencedDialog.isLoading
      ) {
        await performSeriesRemove(suffix);
        return;
      }

      // Show custom confirmation for series removal
      setSeriesRemoveConfirm({ opened: true, suffix });
    },
    [
      seriesRemoveSilencedDialog.isSilenced,
      seriesRemoveSilencedDialog.isLoading,
      performSeriesRemove,
    ],
  );

  // Confirm series removal - called when user confirms dialog
  const confirmSeriesRemove = useCallback(async () => {
    const { suffix } = seriesRemoveConfirm;
    setSeriesRemoveConfirm({ opened: false, suffix: '' });
    await performSeriesRemove(suffix);
  }, [seriesRemoveConfirm, performSeriesRemove]);

  // Cancel series removal - called when user cancels dialog
  const cancelSeriesRemove = useCallback(() => {
    setSeriesRemoveConfirm({ opened: false, suffix: '' });
  }, []);

  // Get view configuration for columns
  const { config: viewConfig } = useViewConfig({ viewName: 'dresses' });

  // Create default detail panel for Series facet
  const detailPanel = useMemo(
    () => createDetailPanel(viewConfig, () => types.DataFacet.SERIES, {}),
    [viewConfig],
  );

  // Create custom handlers for Series facet operations
  const customHandlers = useMemo(
    () => ({
      handleToggle: handleSeriesToggle,
      handleRemove: handleSeriesRemove,
    }),
    [handleSeriesToggle, handleSeriesRemove],
  );

  // Get columns configuration for Series facet
  const currentColumns = useFacetColumns(
    viewConfig,
    () => types.DataFacet.SERIES,
    {
      showActions: useCallback(() => true, []),
      actions: ['toggle', 'remove'] as import('@hooks').ActionType[],
      getCanRemove: useCallback((row: unknown) => {
        const seriesItem = row as { deleted?: boolean };
        return Boolean(seriesItem.deleted);
      }, []),
      getCanToggle: useCallback((row: unknown) => {
        const seriesItem = row as { suffix?: string };
        if (!seriesItem.suffix) return true;
        return seriesItem.suffix !== 'empty';
      }, []),
      getId: useCallback((row: unknown) => {
        const seriesItem = row as { suffix?: string };
        return String(seriesItem.suffix || '');
      }, []),
    },
    customHandlers,
    pageData,
    {
      rowActions: [
        {
          type: 'toggle',
          icon: 'Toggle',
          title: 'Toggle',
          requiresWallet: false,
        },
        {
          type: 'remove',
          icon: 'Remove',
          title: 'Remove',
          requiresWallet: false,
        },
      ],
    },
  );

  // Render Series facet with functional BaseTab
  return (
    <>
      <BaseTab<Record<string, unknown>>
        data={(pageData?.series || []) as unknown as Record<string, unknown>[]}
        columns={currentColumns}
        state={pageData?.state || types.StoreState.STALE}
        error={null}
        viewStateKey={viewStateKey}
        headerActions={null}
        detailPanel={detailPanel}
        onDelete={(_rowData: unknown) => {}}
      />
      <ConfirmModal
        opened={seriesRemoveConfirm.opened}
        onClose={cancelSeriesRemove}
        onConfirm={confirmSeriesRemove}
        title="Confirm Series Removal"
        message={`This will permanently remove the series "${seriesRemoveConfirm.suffix}" and all associated images. This action cannot be undone.`}
        dialogKey="confirm.removeSeries"
      />
    </>
  );
};
