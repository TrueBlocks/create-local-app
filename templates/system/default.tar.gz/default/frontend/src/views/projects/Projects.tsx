import { useEffect, useState } from 'react';

import { GetOpenProjects, NewProject, SwitchToProject } from '@app';
import { Action } from '@components';
import { useViewContext } from '@contexts';
import { useActiveProject, useIconSets } from '@hooks';
import {
  Badge,
  Button,
  Card,
  Container,
  Grid,
  Group,
  Stack,
  Text,
  TextInput,
  Title,
} from '@mantine/core';
import { useForm } from '@mantine/form';
import { Log } from '@utils';
import { useLocation } from 'wouter';

interface ProjectInfo {
  id: string;
  name: string;
  path: string;
  isActive: boolean;
  isDirty: boolean;
  lastOpened: string;
  createdAt: string;
  description?: string;
  addresses?: string[];
  chains?: string[];
}

interface NewProjectForm {
  name: string;
  address: string;
  description: string;
}

export const Projects = () => {
  const [projects, setProjects] = useState<ProjectInfo[]>([]);
  const [recentProjects, setRecentProjects] = useState<ProjectInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [creating, setCreating] = useState(false);

  const { File, Add } = useIconSets();
  const { restoreProjectFilterStates } = useViewContext();
  const { lastView } = useActiveProject();
  const [, navigate] = useLocation();

  const form = useForm<NewProjectForm>({
    initialValues: {
      name: '',
      address: '',
      description: '',
    },
    validate: {
      name: (value) => (!value ? 'Project name is required' : null),
      address: (value) => {
        if (!value) return 'Primary address is required';
        if (value.endsWith('.eth')) {
          if (value.length < 5) return 'ENS name too short';
          if (!/^[a-z0-9-]+\.eth$/i.test(value))
            return 'Invalid ENS name format';
          return null;
        }
        if (!/^0x[a-fA-F0-9]{40}$/.test(value)) {
          return 'Invalid Ethereum address format (use 0x... or .eth name)';
        }
        return null;
      },
    },
  });

  const fetchProjects = async () => {
    try {
      setLoading(true);
      const openProjects = await GetOpenProjects();

      const typedOpenProjects = openProjects as unknown as ProjectInfo[];

      // Sort projects by last opened date
      const sortedOpen = typedOpenProjects.sort(
        (a, b) =>
          new Date(b.lastOpened).getTime() - new Date(a.lastOpened).getTime(),
      );

      setProjects(sortedOpen);
      setRecentProjects([]); // No recent projects API yet
      setError(null);
    } catch (err) {
      Log(`Error fetching projects: ${err}`);
      setError('Failed to load projects');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleCreateProject = async (values: NewProjectForm) => {
    try {
      setCreating(true);
      await NewProject(values.name, values.address);

      // Refresh projects list
      await fetchProjects();

      // Reset form and hide create form
      form.reset();
      setShowCreateForm(false);

      Log(`Created new project: ${values.name}`);
    } catch (err) {
      Log(`Error creating project: ${err}`);
      setError(`Failed to create project: ${err}`);
    } finally {
      setCreating(false);
    }
  };

  const handleSwitchProject = async (projectId: string) => {
    try {
      await SwitchToProject(projectId);
      await restoreProjectFilterStates();

      const targetView = lastView || '/';
      navigate(targetView);

      Log(`Switched to project: ${projectId}`);
    } catch (err) {
      Log(`Error switching projects: ${err}`);
      setError(`Failed to switch to project: ${err}`);
    }
  };

  // Filter projects based on search query
  const filteredProjects = projects.filter(
    (project) =>
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (project.description &&
        project.description.toLowerCase().includes(searchQuery.toLowerCase())),
  );

  const filteredRecentProjects = recentProjects.filter(
    (project) =>
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.path.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  const renderProject = (project: ProjectInfo, isRecent = false) => (
    <Card key={project.id} shadow="sm" padding="md" radius="md" withBorder>
      <Stack gap="xs">
        <Group justify="space-between" align="flex-start">
          <div style={{ flex: 1 }}>
            <Group gap="xs" align="center">
              <Title order={5} size="sm">
                {project.name}
              </Title>
              {project.isActive && (
                <Badge size="xs" color="green">
                  Active
                </Badge>
              )}
              {project.isDirty && (
                <Badge size="xs" color="orange">
                  Modified
                </Badge>
              )}
            </Group>

            <Text size="xs" c="dimmed" mt="2px">
              {project.path}
            </Text>

            {project.description && (
              <Text size="xs" mt="xs" lineClamp={2}>
                {project.description}
              </Text>
            )}

            <Group gap="xs" mt="xs">
              <Text size="xs" c="dimmed">
                Last opened: {new Date(project.lastOpened).toLocaleDateString()}
              </Text>
              {project.addresses && project.addresses.length > 0 && (
                <Badge size="xs" variant="light">
                  {project.addresses.length} address
                  {project.addresses.length > 1 ? 'es' : ''}
                </Badge>
              )}
            </Group>
          </div>

          <Group gap="xs">
            {!project.isActive && (
              <Action
                icon="Switch"
                title="Switch to this project"
                color="blue"
                variant="light"
                size="sm"
                onClick={() => handleSwitchProject(project.id)}
              />
            )}
            <Action
              icon="Edit"
              title="Edit project"
              color="gray"
              variant="light"
              size="sm"
              onClick={() => {
                // TODO: Implement project editing
                Log('Edit project clicked - not implemented yet');
              }}
            />
            {!isRecent && (
              <Action
                icon="Delete"
                title="Close project"
                color="red"
                variant="light"
                size="sm"
                onClick={() => {
                  // TODO: Implement project closing with confirmation
                  Log('Close project clicked - not implemented yet');
                }}
              />
            )}
          </Group>
        </Group>
      </Stack>
    </Card>
  );

  return (
    <Container size="lg" py="md">
      <Stack gap="xl">
        {/* Header */}
        <Group justify="space-between" align="center">
          <div>
            <Title order={2}>Project Manager</Title>
            <Text c="dimmed">Manage your {{ORG_NAME}} analysis projects</Text>
          </div>

          <Button
            leftSection={<Add size={16} />}
            onClick={() => setShowCreateForm(!showCreateForm)}
            variant={showCreateForm ? 'light' : 'filled'}
          >
            {showCreateForm ? 'Cancel' : 'New Project'}
          </Button>
        </Group>

        {/* Error Display */}
        {error && (
          <Text c="red" size="sm">
            {error}
          </Text>
        )}

        {/* Create Project Form */}
        {showCreateForm && (
          <Card shadow="sm" padding="lg" radius="md" withBorder>
            <Title order={4} mb="md">
              Create New Project
            </Title>

            <form onSubmit={form.onSubmit(handleCreateProject)}>
              <Stack gap="md">
                <Grid>
                  <Grid.Col span={{ base: 12, md: 6 }}>
                    <TextInput
                      label="Project Name"
                      placeholder="My Analysis Project"
                      required
                      {...form.getInputProps('name')}
                    />
                  </Grid.Col>
                  <Grid.Col span={{ base: 12, md: 6 }}>
                    <TextInput
                      label="Primary Address"
                      placeholder="0x... or vitalik.eth"
                      required
                      {...form.getInputProps('address')}
                    />
                  </Grid.Col>
                </Grid>

                <TextInput
                  label="Description (Optional)"
                  placeholder="Brief description of this project"
                  {...form.getInputProps('description')}
                />

                <Group gap="xs">
                  <Button
                    type="submit"
                    loading={creating}
                    leftSection={<Add size={16} />}
                  >
                    Create Project
                  </Button>
                  <Button
                    variant="light"
                    onClick={() => {
                      setShowCreateForm(false);
                      form.reset();
                    }}
                  >
                    Cancel
                  </Button>
                </Group>
              </Stack>
            </form>
          </Card>
        )}

        {/* Search */}
        <Group gap="md">
          <TextInput
            placeholder="Search projects..."
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.currentTarget.value)}
            style={{ flex: 1 }}
          />
        </Group>

        {/* Open Projects */}
        <div>
          <Title order={3} mb="md">
            Open Projects ({filteredProjects.length})
          </Title>

          {loading ? (
            <Text>Loading projects...</Text>
          ) : filteredProjects.length === 0 ? (
            <Card shadow="sm" padding="xl" radius="md" withBorder>
              <Stack align="center" gap="md">
                <File size={48} opacity={0.5} />
                <div style={{ textAlign: 'center' }}>
                  <Text size="lg" fw={500}>
                    {searchQuery
                      ? 'No projects match your search'
                      : 'No open projects'}
                  </Text>
                  <Text c="dimmed" size="sm">
                    {searchQuery
                      ? 'Try a different search term or clear the search'
                      : 'Create a new project to get started with blockchain analysis'}
                  </Text>
                </div>
                {!searchQuery && (
                  <Button
                    leftSection={<Add size={16} />}
                    onClick={() => setShowCreateForm(true)}
                  >
                    Create Your First Project
                  </Button>
                )}
              </Stack>
            </Card>
          ) : (
            <Grid>
              {filteredProjects.map((project) => (
                <Grid.Col key={project.id} span={{ base: 12, md: 6, lg: 4 }}>
                  {renderProject(project)}
                </Grid.Col>
              ))}
            </Grid>
          )}
        </div>

        {/* Recent Projects */}
        {recentProjects.length > 0 && (
          <div>
            <Title order={3} mb="md">
              Recent Projects ({filteredRecentProjects.length})
            </Title>

            {filteredRecentProjects.length === 0 ? (
              <Text c="dimmed" size="sm">
                No recent projects match your search
              </Text>
            ) : (
              <Grid>
                {filteredRecentProjects.slice(0, 6).map((project) => (
                  <Grid.Col key={project.id} span={{ base: 12, md: 6, lg: 4 }}>
                    {renderProject(project, true)}
                  </Grid.Col>
                ))}
              </Grid>
            )}
          </div>
        )}
      </Stack>
    </Container>
  );
};
