export { ProjectsFacet } from './ProjectsFacet';
