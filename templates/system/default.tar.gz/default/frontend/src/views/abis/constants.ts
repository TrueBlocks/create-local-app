import { ViewRoute } from '../routes';

export const ROUTE: ViewRoute = 'abis';
