export { renderApprovalDetailPanel } from './ApprovalPanel';
