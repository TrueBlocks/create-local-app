export { renderStatementDetailPanel } from './StatementPanel';
