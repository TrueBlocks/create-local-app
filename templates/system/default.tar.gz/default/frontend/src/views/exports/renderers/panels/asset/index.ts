export { renderAssetDetailPanel } from './AssetPanel';
