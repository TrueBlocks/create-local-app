export { ComparitoorFacet } from './ComparitoorFacet';
