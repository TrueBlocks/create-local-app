export { ComparitoorFacet } from './comparitoor';
