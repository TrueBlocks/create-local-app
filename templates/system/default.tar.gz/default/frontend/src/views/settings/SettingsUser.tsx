export const SettingsUser = () => {
  return (
    <div>
      <h2>User Settings</h2>
      <p>Placeholder for user settings.</p>
    </div>
  );
};
