export const SettingsApp = () => {
  return (
    <div>
      <h2>App Settings</h2>
      <p>Placeholder for app settings.</p>
    </div>
  );
};
