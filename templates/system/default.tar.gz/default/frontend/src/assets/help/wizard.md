## This is the Wizard

It helps you figure out what's going on.
