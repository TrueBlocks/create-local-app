**Settings App**
================

Settings App is where you can manage your application settings. You can set the name of your application, the default language, and the default time zone. You can also manage your application users and their roles.
