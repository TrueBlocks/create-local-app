**Settings Org**
================

Settings Org is where you can manage your organization settings. You can set the name of your organization, the default language, and the default time zone. You can also manage your organization members and their roles.
