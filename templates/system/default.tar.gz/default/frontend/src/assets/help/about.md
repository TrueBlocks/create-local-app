This app generates code from your configuration.

- Built with Wails + Mantine
- Sidebar toggles for navigation and help
- Preferences are persisted automatically

Use the left menu to switch views.
