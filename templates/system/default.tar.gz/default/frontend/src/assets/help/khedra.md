This screen controls Khedra's settings. The following options are available:

- **Khedra**: This option allows you to enable or disable Khedra. When enabled, Khedra will be active and will respond to your commands. When disabled, Khedra will not respond to any commands.
- **Khedra**: This option allows you to enable or disable Khedra. When enabled, Khedra will be active and will respond to your commands. When disabled, Khedra will not respond to any commands.
