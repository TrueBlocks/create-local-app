This is the main dashboard of your application.

- Use the menu to explore other views
- The help bar will update contextually
