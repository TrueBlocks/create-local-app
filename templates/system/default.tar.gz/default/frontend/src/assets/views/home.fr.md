This is the french version of the home page help
