export type TimeGroupBy = 'daily' | 'monthly' | 'quarterly' | 'annual';
