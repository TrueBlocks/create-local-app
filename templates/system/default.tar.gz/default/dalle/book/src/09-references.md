# References

- [**{{ORG_LOWER}}-dalle** GitHub Repository](https://github.com/{{ORG_LOWER}}/dalle)
- [Original Design Document](https://docs.google.com/document/d/1jNUonGHN6mHT4FqrmI7TlS82epNOqHECcxwobLQGxTo/edit?tab=t.0)
- [Go Documentation](https://golang.org/doc/)
- [mdBook Documentation](https://rust-lang.github.io/mdBook/)
