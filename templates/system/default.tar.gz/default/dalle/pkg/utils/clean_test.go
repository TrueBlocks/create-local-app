package utils

// Functions to test from clean.go:
//   - Clean
//
// If adding tests, focus on file/series cleanup logic and error handling.
