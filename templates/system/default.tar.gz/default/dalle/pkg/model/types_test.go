package model

// Placeholder note: types.go defines Database and Generator. Add behavior tests if logic grows.
