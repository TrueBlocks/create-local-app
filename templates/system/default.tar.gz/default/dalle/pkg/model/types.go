package model

type Database struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}

type Generator struct {
	ID   string `json:"id"`
	Name string `json:"name"`
}
