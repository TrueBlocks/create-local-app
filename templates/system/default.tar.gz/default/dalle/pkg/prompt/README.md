# pkg/prompt

This package contains all prompt construction, enhancement, and OpenAI API logic for the project.

- Prompt templates and generation
- Attribute handling
- OpenAI integration
