# Rules of Engagement for Managing the To Do List

1. **Source of information**:
   - The above conversation detailing the requirements for the feature is the primary source of information for you as you create a To Do list.
   - The AI must never hallucinate or make assumptions about how any code works. Always either search the codebase to find missing information or ask the user for clarifications.
   - The AI must never make assumptions about third party libraries or external APIs (such as `React` or `Mantine`). Always consult the latest online documentation if there are any questions or ask the user for clarifications.
   - The AI must always self-review its code for syntax, logic, and style errors, and simulate test coverage before making any file changes. If any requirement is unclear, the AI must always ask the user for clarification. For example: "Can you clarify if step numbers should reset for each task or be global across all tasks?"

2. **File Location**:
   - The To Do list must be saved in the file located at `./ai/ToDoList.md`.
   - If that file already exists, overwrite it.
   - Create the `./ai` folder and any missing parent directories for any file the AI needs to write, if they do not already exist.

3. **Table Structure**:
   - The To Do list must be presented as a Markdown table with the following columns:
       - **Task**: Contains the task description, with the task number prepended (e.g., `1. Move management of X to component Y`).
       - **Step**: Contains the step description, with the step number prepended (e.g., `1. Remove X from its previous location`).
       - **Done**: Indicates whether the step is complete. Use a green check (✅) for completed steps and `-` for incomplete steps. Center align the `Done` column using `:---:` in the Markdown table.
   - The table should be formatted to ensure readability, avoiding excessive horizontal scrolling or overly narrow columns.

4. **Task and Step Numbering**:
   - Task numbers are integers (e.g., `1`, `2`, `3`).
   - Step numbers are also integers (e.g., `1`, `2`, `3`).
   - Task numbers are prepended to the task description in the **Task** column.
   - Step numbers are prepended to the step description in the **Step** column.
   - Step numbers reset for each task (e.g., 1.1, 1.2, 2.1, 2.2).
   - The user (and the AI as well) shall refer to steps using `number.number` (for example, `1.4`, `2.1`, etc.).

5. **Marking Completion**:
   - When a step is completed, mark the **Done** column with ✅.
   - When all steps in a task are completed and the Checkpoint is confirmed, move the task to the bottom of the ToDoList.md file in a separate table devoted to fully completed tasks.

6. **Updating the To Do List**:
   - Always edit the To Do list in the Markdown file (`./ai/ToDoList.md`).
   - Remove any temporary files created during operation.
   - Do not display or preview the Markdown; these instructions apply only to writing and editing the ToDoList markdown file.

7. **Interaction Rules**:
   - When working on a specific task or step, show only the relevant task and its steps unless explicitly asked to display the entire To Do list with the command "Show all".
   - If asked "Where are we?", display the current task and step.

8. **Handling Dependencies**:
   - Steps within a task should reflect dependencies on other steps or tasks through their ordering. No additional representation of dependencies is required.
   - Never use npm, npx, or any npm-related commands for anything. Use exclusively yarn for all package and script operations.

9.  **Task Requirements**:
    - Every task must have at least one step.
    - If a task has no steps, it should be removed as it is not a valid task.

10. **Formatting for Long Descriptions**:
    - If a task or step description is too long, it should be wrapped to maintain a reasonable table width. 
    - The table width should remain visually manageable.

11. **Code Generation**:
    - When generating code, always use the latest version of the codebase as a reference, reloading files if they've changed since you last loaded them.
    - Before generating code, read `./frontend/eslint.config.js` and `./frontend/tsconfig.json` to understand the code style and linting rules. Obey them.
    - When generating typescript code, do not import `React`. It's implicitly imported in the project.
    - Break the tasks into logical steps or checkpoints. After each logical step (or checkpoint), put a row in the table called "Checkpoint" and do not proceed past the checkpoint until the user has confirmed that the code is correct and working. The AI must always wait for explicit user confirmation before proceeding past a checkpoint.
    - It would be beneficial to provide testing code for the newly generated code just before the checkpoints. 

12. **Code Formatting (IMPORTANT)**:
    - Never under any circumstances generate any comments in any code, including tests and documentation.
    - In Typescript code, never use `console.log`, use the backend's Logger function instead.
    - When generating Typescript, obey the formatting and linter settings in `.prettierrc`, `eslint.config.js`, and `tsconfig.json`.
    - Format code using the same formatting that Visual Studio Code applies on save for `.go` and `.tsx` files.
    - Never under any circumstances generate any comments.

13. **Testing with Vitest**:
    - Always use Vitest for testing, never Jest.
    - Import test utilities directly from Vitest: `import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'`.
    - For component testing, use React Testing Library: `import { render, screen, fireEvent } from '@testing-library/react'`.
    - For hook testing, use: `import { renderHook, act } from '@testing-library/react'`.
    - Use `vi.mock()` for mocking dependencies, not Jest's `jest.mock()`.
    - Use `vi.fn()` for mock functions, not `jest.fn()`.
    - Use `vi.spyOn()` for spying on methods, not `jest.spyOn()`.
    - All tests should be in files with `.test.tsx` or `.test.ts` extensions.
    - Place test files in a `__tests__` directory adjacent to the code being tested.
    - Use `beforeEach` and `afterEach` for setup and teardown.
    - Run tests using `yarn test` from the root of the repository. For watch mode, use `yarn test --watch` from the root.
    - For specific tests, use `yarn test path/to/test/file` or `yarn test -t 'test name pattern'` from the root.
    - Mock timer functions with `vi.useFakeTimers()` and `vi.useRealTimers()`.
    - For testing asynchronous code, use `await` or return promises.
    - When testing components that use contexts, always provide mock context providers.
    - Remember that `describe`, `it`, and `expect` are globally available due to Vitest configuration.

14. **Linting**:
    - Run linter using `yarn lint` from the root of the repository.
    - If linting fails, the AI must stop and give the user a chance to fix the issues before proceeding.

15. **Error Handling**:
    - If tests fail, the AI must stop and give the user a chance to review and fix the issues before proceeding.

16. **Temporary Files**:
    - The AI must remove any temporary files it creates during operation.

17. **Handling Ambiguity**:
    - If any requirement is unclear, the AI must always ask the user for clarification. For example: "Can you clarify if step numbers should reset for each task or be global across all tasks?"

Important things to remember:

- Make sure to (a) make no comments, (b) always use yarn never use npm, (c) run tests and linter after making significant changes.
